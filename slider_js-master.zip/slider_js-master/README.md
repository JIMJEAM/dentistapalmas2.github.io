# Crea un Slider con JavaScript, Html5 y CSS3
Holaaa!! 

Pequeños guerreros

Vamos a aprender a realizar un slider en HTML5, CSS3, JavaScript.
Dale dinamismo a tu página con un animado slider. 


Reset navegadores:
https://gist.github.com/bezael/665d57d7a90c17ae781ceb26c6bdd7dc

Banco de Imagenes:
https://pixabay.com/

Facebook: https://www.facebook.com/dominicodee/

Twitter : https://twitter.com/domini_code

Suscribete al canal: https://www.youtube.com/c/DominiCode?sub_confirmation=1 

Web: dominicode.com
